#include<stdio.h>
int main()
{
int x=10;
int *p;
p=&b;
printf("Value of x:%d",x);
printf("Value of p:%d",*p);
return 0;
}