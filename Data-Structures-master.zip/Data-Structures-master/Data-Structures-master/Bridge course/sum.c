#include<stdio.h>
void main()
{
int s=0,i;
for(i=1;i<=10;i++)
{
s=s+i;
}
printf("sum of numbers from 1 to 10 is : %d ",s);
}
