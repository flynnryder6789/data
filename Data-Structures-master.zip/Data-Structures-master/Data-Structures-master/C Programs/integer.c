#include <stdio.h>
int main()
{
    int n1;
    int n2;

    printf("Enter a number: ");
    scanf("%d", &n1);
    printf("Enter another number: ");
    scanf("%d", &n2);

    printf("num1 = %d\n", n1);
    printf("num2 = %d", n2);

    return 0;
}